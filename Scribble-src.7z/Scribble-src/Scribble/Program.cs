﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Scribble
{
    class Program
    {
        struct Coord
        {
            public int screenX, screenY, gameboardCol, gameboardRow, gameboardX, gameboardY;
        }
        struct LetterInfo
        {
            public int X, Y;
        }
        struct Player
        {
            public string name;
            public int number, score;
            public char[] bag;
        };
        struct GameboardCell
        {
            public char cell;
            public bool highLighted;
        }
        struct WordInfo
        {
            public int startX, startY, endX, endY;
        }
        struct GameInfo
        {
            public GameboardCell[][] gameboard;
            public Player[] players;
            public string[][] letters;
            public int player, numOfPass, round, leftQuery, formCounter;
        }
        struct GameSetting
        {
            public string[] names;
            public int seqPassLimit, theme, roundLimit;
        }
        struct Theme
        {
            public ConsoleColor DefaultBackGround, DefaultForeGround, SelectedBackGround, SelectedForeground, IndexedForeground, IndexedBackGround, HighlightedBackGround, BagForeGroung, BoardForeGround, PopUpBackGround;
        }
        static Theme[] themes = new Theme[3];
        static void Main(string[] args)
        {
            startGame();
        }
        static void startGame()
        {
            createThemes();
            string[] dictionary = readFile("dictionary_1.txt");
            string[] letters_base = readFile("letter_reservoir_1.txt");
            string[] sets = readFile("sets");
            string[] helpTxt = readFile("hlp");
            if (dictionary == null || letters_base == null||helpTxt==null||dictionary.Length==0||letters_base.Length==0||helpTxt.Length==0) return;
            if (sets == null || sets[0][0] != '\0')
            {
                sets = new string[6];
                sets[0] = Convert.ToString('\0');
                sets[1] = "Player 1";
                sets[2] = "Player 2";
                sets[3] = Convert.ToString(0);
                sets[4] = Convert.ToString(4);
                sets[5] = Convert.ToString(0);
            }
            GameSetting settings=loadSettings(sets);
            saveSettings(settings);
            Encoding encoder = Console.OutputEncoding;
            initializeConsole(50, 110,settings.theme);//konsolu hazırla
            Random rand = new Random();
            Player[] players = new Player[2];
            GameInfo gameInfo = new GameInfo();
            gameInfo.gameboard = createGameboard(33, 48);
            gameInfo.letters = new string[3][];
            for (int i = 0; i < gameInfo.letters.Length; i++) gameInfo.letters[i] = new string[26];
            gameInfo.players = new Player[2];
            gameInfo.players[0].bag = new char[7];
            gameInfo.players[1].bag = new char[7];
            intro(settings);
            while (true)
            {
                Console.Clear();
                string[] gameInfoStr = readFile("svg");
                bool oldGameExist;
                if (gameInfoStr != null && gameInfoStr.Length == 1670 && gameInfoStr[0][0] == '\0') oldGameExist = true;
                else oldGameExist = false;
                int selection = menu(encoder, settings, oldGameExist,helpTxt);
                if (selection == 0) return;
                settings = loadSettings(readFile("sets"));
                gameInfo = loadGame(players, letters_base, settings, gameInfo, gameInfoStr, rand, selection);
                Console.Clear();
                gameProcess(gameInfo, settings, dictionary, encoder, rand);
            }
        }
        static void gameProcess(GameInfo gameInfo,GameSetting settings,string[] dictionary,Encoding encoder,Random rand)
        {
            bool gameover = false;
            int player = gameInfo.player;
            Player[] players = gameInfo.players;
            GameboardCell[][] gameboard = gameInfo.gameboard;
            string[][] letters = gameInfo.letters;
            int numOfPass = gameInfo.numOfPass;
            int round = gameInfo.round;
            int leftQuery = gameInfo.leftQuery;
            int formCounter = gameInfo.formCounter;
            bool saved = true;
            while (!gameover)
            {
                Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                drawBox(43, 13, 22, 9, true, (int)' ');
                drawBox(43, 13, 22, 9, false, 177);
                Console.SetCursorPosition(47, 16);
                printASCII(players[player].name+"'s", encoder);
                Console.SetCursorPosition(50, 18);
                Console.Write("TURN");
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                System.Threading.Thread.Sleep(1000);
                while (true)
                {
                    printGameboard(players, player, gameboard, letters, numOfPass, round, settings, encoder);
                    int selection = select(dictionary, ref leftQuery,ref saved,settings);
                    if (selection == 1)
                    {
                        if (changeLetters(players[player], letters, rand,settings))
                        {
                            saved = false; numOfPass++; break;
                        }
                    }
                    else if (selection == 2)
                    {
                        saved = false; numOfPass++; break;
                    }
                    else if (selection == 3)
                    {
                        int secilen = 0;
                        while (true)
                        {
                            printGameboard(players, player, gameboard, letters, numOfPass, round, settings,encoder);
                            secilen = formWord(settings,players, player, gameboard, dictionary, letters,ref saved, rand);
                            if (secilen == 2) formCounter++;
                            else if (secilen == 4) { }
                            else break;
                            if (formCounter == 3) break;
                        }
                        if (formCounter == 3)
                        {
                            numOfPass++; break;
                        }
                        else if (secilen == 1)
                        {
                            numOfPass = 0; break;
                        }
                    }
                    else if (selection == 4)
                    {
                        if (saved) return;
                        Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                        drawBox(42, 15, 25, 15, true, ' ');
                        drawBox(42, 15, 25, 15, false, (char)177);
                        Console.SetCursorPosition(47, 19);
                        Console.Write("Do you want to");
                        Console.SetCursorPosition(47, 20);
                        Console.Write("save your game");
                        Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                        NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
                        NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
                        int index = 1;
                        while (true)
                        {
                            int key = 0;
                            Console.SetCursorPosition(46, 25);
                            Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                            Console.Write("                   ");
                            if (index == 1)
                            {
                                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                                Console.SetCursorPosition(48, 25);
                                Console.Write(" NO ");
                                Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                                Console.SetCursorPosition(57, 25);
                                Console.Write(" YES ");
                            }
                            else if (index == 2)
                            {
                                Console.SetCursorPosition(48, 25);
                                Console.Write(" NO ");
                                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                                Console.SetCursorPosition(57, 25);
                                Console.Write(" YES ");
                                Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                            }
                            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                            while (true)
                            {
                                record = NativeMethods.RecordEvent(handle, record);
                                if (record.EventType == NativeMethods.MOUSE_EVENT)
                                {
                                    if (record.MouseEvent.dwButtonState == 1)
                                    {
                                        while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                                        if (index == 1) return;
                                        else
                                        {
                                            gameInfo.formCounter = formCounter;
                                            gameInfo.gameboard = gameboard;
                                            gameInfo.leftQuery = leftQuery;
                                            gameInfo.letters = letters;
                                            gameInfo.numOfPass = numOfPass;
                                            gameInfo.player = player;
                                            gameInfo.players = players;
                                            gameInfo.round = round;
                                            saveGame(gameInfo);
                                            return;
                                        }
                                    }
                                    if (record.MouseEvent.dwMousePosition.Y < 27 && record.MouseEvent.dwMousePosition.Y > 23 && record.MouseEvent.dwButtonState == 0)
                                    {
                                        if (record.MouseEvent.dwMousePosition.X < 52 && record.MouseEvent.dwMousePosition.X > 47 && index != 1)
                                        {
                                            index = 1; break;
                                        }
                                        else if (record.MouseEvent.dwMousePosition.X < 62 && record.MouseEvent.dwMousePosition.X > 56 && index != 2)
                                        {
                                            index = 2; break;
                                        }
                                    }
                                }
                                else if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                                {
                                    key = record.KeyEvent.wVirtualKeyCode;
                                    if (key == (int)ConsoleKey.LeftArrow && index > 1)
                                    {
                                        index--; break;
                                    }
                                    else if (key == (int)ConsoleKey.RightArrow && index < 2)
                                    {
                                        index++; break;
                                    }
                                    else if (key == (int)ConsoleKey.Enter)
                                    {
                                        if (index == 1) return;
                                        else
                                        {
                                            gameInfo.gameboard = gameboard;
                                            gameInfo.leftQuery = leftQuery;
                                            gameInfo.letters = letters;
                                            gameInfo.numOfPass = numOfPass;
                                            gameInfo.player = player;
                                            gameInfo.players = players;
                                            gameInfo.round = round;
                                            saveGame(gameInfo);
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if(selection==5)
                    {
                        saved = true;
                        gameInfo.formCounter = formCounter;
                        gameInfo.gameboard = gameboard;
                        gameInfo.leftQuery = leftQuery;
                        gameInfo.letters = letters;
                        gameInfo.numOfPass = numOfPass;
                        gameInfo.player = player;
                        gameInfo.players = players;
                        gameInfo.round = round;
                        Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
                        Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                        drawBox(42, 15, 25, 15, true, ' ');
                        drawBox(42, 15, 25, 15, false, (char)177);
                        Console.SetCursorPosition(45, 22);
                        Console.Write("Successfully Saved");
                        Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                        System.Threading.Thread.Sleep(1000);
                        saveGame(gameInfo);
                    }
                }
                formCounter = 0; player = (player + 1) % 2; round++;
                leftQuery = 3; gameover = isGameOver(numOfPass, letters, round, settings);
            }
            Console.BackgroundColor = themes[settings.theme].PopUpBackGround;
            drawBox(41, 10, 26, 15, true, ' ');
            drawBox(41, 10, 26, 15, false, (char)177);
            Console.SetCursorPosition(46, 12);
            printASCII(players[0].name, encoder);
            Console.Write(" : {0}", players[0].score);
            Console.SetCursorPosition(46, 14);
            printASCII(players[1].name, encoder);
            Console.Write(" : {0}", players[1].score);
            int max;
            if (players[0].score == players[1].score)
            {
                Console.SetCursorPosition(50, 17); Console.Write("DRAW");
            }
            else
            {
                max = (players[0].score > players[1].score) ? 0 : 1;
                Console.SetCursorPosition(49, 16);
                printASCII(players[max].name, encoder);
                Console.SetCursorPosition(47, 17);
                Console.Write("WON THE GAME");
            }
            Console.SetCursorPosition(45, 20);
            Console.Write("Press any key to");
            Console.SetCursorPosition(45, 21);
            Console.Write("return to menu");
            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
            Console.ReadKey(true);
        }
        static GameInfo loadGame(Player[] players, string[] letters_base,GameSetting settings, GameInfo gameInfo, string[] gameInfoStr, Random rand, int m)
        {
            if (m == 1)
            {
                gameInfo.gameboard = createGameboard(33, 48);
                gameInfo.players[0].bag = new char[7];
                gameInfo.players[1].bag = new char[7];
                gameInfo.letters = optimizeLettersArray(letters_base);
                gameInfo.numOfPass = 0;
                gameInfo.player = 0;
                gameInfo.round = 1;
                fillBag(gameInfo.players[0].bag, gameInfo.letters, rand);
                gameInfo.players[0].name = settings.names[0];
                gameInfo.players[0].number = 1;
                gameInfo.players[0].score = 0;
                fillBag(gameInfo.players[1].bag, gameInfo.letters, rand);
                gameInfo.players[1].name = settings.names[1];
                gameInfo.players[1].number = 2;
                gameInfo.players[1].score = 0;
                gameInfo.leftQuery = 3;
            }
            else if (m == 2) gameInfo = loadSgame(gameInfo, gameInfoStr);
            return gameInfo;
        }
        static void initializeConsole(int height, int width,int theme)
        {
            Console.Title = "Scribble"; //Pencere ismi ayarlandı
            Console.SetWindowSize(width, height);//Pencere boyutunu ayarlar
            Console.BufferHeight = height;//Scroll barı yok olsun diye 
            Console.BufferWidth = width; //buffer pencere boyutuna eşitlendi
            Console.CursorVisible = false;//kursör gizledi
            Console.BackgroundColor = themes[theme].DefaultBackGround;
            Console.ForegroundColor = themes[theme].DefaultForeGround;
            Console.Clear();
            Console.OutputEncoding = System.Text.Encoding.Default;
        }
        static string[] readFile(string path)
        {
            try
            {
                return File.ReadAllLines(path);
            }
            catch (FileNotFoundException)
            {
                return null;
            }
        }
        static string[][] optimizeLettersArray(string[] base_array)
        {
            string[][] letters = new string[3][];
            for (int i = 0; i < 3; i++) letters[i] = new string[base_array.Length];
            for (int i = 0; i < base_array.Length; i++)
            {
                string[] str = base_array[i].Split();
                for (int j = 0; j < 3; j++) letters[j][i] = str[j];
            } return letters;
        }
        static bool isExist(string word, string[] dictionary)
        {
            for (int i = 0; i < dictionary.Length; i++) if (word == dictionary[i]) return true; return false;
        }
        static void printASCII(string str, Encoding encoder)
        {
            Console.OutputEncoding = encoder;
            Console.Write(str);
            Console.OutputEncoding = System.Text.Encoding.Default;
        }
        static int calculatePoint(string word, string[][] letters)
        {
            int point = 0;
            for (int i = 0; i < word.Length; i++)
                for (int j = 0; j < letters[0].Length; j++)
                    if (word[i] == letters[0][j][0])
                    {
                        point += Convert.ToInt32(letters[1][j]);
                        break;
                    }
            return point;
        }
        static string[] query(string query, string[] dictionary, int queryListLength)
        {
            if (queryListLength <= 0 || query == null) return null;
            string[] queryList = new string[queryListLength];
            int queryListIndex = 0; int searchIndex = 0;
            for (; queryListIndex < queryListLength && searchIndex < dictionary.Length; searchIndex++)
                if (query.Length == dictionary[searchIndex].Length)
                {
                    int i = 0;
                    for (i = 0; i < query.Length; i++)
                    {
                        if (query[i] != '.' && query[i] != dictionary[searchIndex][i])
                        {
                            break;
                        }
                    }
                    if (i == query.Length)
                    {
                        queryList[queryListIndex] = dictionary[searchIndex];
                        queryListIndex++;
                    }
                } return queryList;
        }
        static GameboardCell[][] createGameboard(int height, int width)
        {
            GameboardCell[][] gameboard = new GameboardCell[height][];
            for (int i = 0; i < gameboard.Length; i++) gameboard[i] = new GameboardCell[width];
            for (int i = 0; i < gameboard.Length; i++)
                for (int j = 0; j < gameboard[i].Length; j++)
                {
                    gameboard[i][j].highLighted = false;
                    if (i == 0 || i == gameboard.Length - 1)
                    {
                        gameboard[i][j].cell = (char)177;
                    }
                    else if (j == 0 || j == gameboard[i].Length - 1)
                    {
                        gameboard[i][j].cell = (char)177;
                    }
                    else if (i == 1)
                    {
                        if (j == 1)
                        {
                            gameboard[i][j].cell = (char)218;
                        }
                        else if (j == gameboard[i].Length - 2)
                        {
                            gameboard[i][j].cell = (char)191;
                        }
                        else if (j % 3 == 1)
                        {
                            gameboard[i][j].cell = (char)194;
                        }
                        else
                        {
                            gameboard[i][j].cell = (char)196;
                        }
                    }
                    else if (i == gameboard.Length - 2)
                    {
                        if (j == 1)
                        {
                            gameboard[i][j].cell = (char)192;
                        }
                        else if (j == gameboard[i].Length - 2)
                        {
                            gameboard[i][j].cell = (char)217;
                        }
                        else if (j % 3 == 1)
                        {
                            gameboard[i][j].cell = (char)193;
                        }
                        else
                        {
                            gameboard[i][j].cell = (char)196;
                        }
                    }
                    else if (i % 2 == 0 && j % 3 == 1)
                    {
                        gameboard[i][j].cell = (char)179;
                    }
                    else if (j == 1)
                    {
                        gameboard[i][j].cell = (char)195;
                    }
                    else if (j == gameboard[i].Length - 2)
                    {
                        gameboard[i][j].cell = (char)180;
                    }
                    else if (j % 3 == 1)
                    {
                        gameboard[i][j].cell = (char)197;
                    }
                    else if (i % 2 == 1)
                    {
                        gameboard[i][j].cell = (char)196;
                    }
                } return gameboard;
        }
        static bool isGameOver(int numOfPass, string[][] letters,int round,GameSetting setting)
        {
            if (setting.roundLimit != 0 && round > setting.roundLimit) return true;
            if (setting.seqPassLimit <= numOfPass) return true;
            if (reservoirLetters(letters) == 0) return true; return false;
        }
        static int reservoirLetters(string[][] letters)
        {
            int total = 0;
            for (int i = 0; i < letters[0].Length; i++) total += Convert.ToInt32(letters[2][i]);
            return total;
        }
        static char randomLetter(string[][] letters, Random rand)
        {
            int totalAmount = reservoirLetters(letters);
            if (totalAmount == 0) return (char)0;
            int index = letters[0].Length;
            int random = rand.Next() % totalAmount;
            while(totalAmount>random)
            {
                index--;
                totalAmount -= Convert.ToInt32(letters[2][index]);
            }
            int numOfLetter = Convert.ToInt32(letters[2][index]);
            letters[2][index] = Convert.ToString(numOfLetter - 1);
            return letters[0][index][0];
        }
        static int fillBag(char[] bag, string[][] letters, Random rand)
        {
            int counter = 0;
            for (int i = 0; i < bag.Length; i++)
                if (bag[i] == '\0')
                {
                    bag[i] = randomLetter(letters, rand);
                    if (bag[i] == (char)0)
                    {
                        bag[i] = '\0';
                        return counter;
                    }
                    counter++;
                } return counter;
        }
        static void drawBox(int x, int y, int width, int height, bool fill, int chr)
        {
            Console.SetCursorPosition(x, y);
            for (int i = 0; i < height; i++)
                for (int j = 0; j < width; j++)
                {
                    if (fill)
                    {
                        Console.SetCursorPosition(x + j, i + y);
                        Console.Write((char)chr);
                    }
                    else if (i == 0 || i == height - 1 || j == 0 || j == width - 1)
                    {
                        Console.SetCursorPosition(x + j, i + y);
                        Console.Write((char)chr);
                    }
                }
        }
        static void printGameboard(Player[] players, int player, GameboardCell[][] gameboard, string[][] letters, int numOfPass, int round,GameSetting settings, Encoding encoder)
        {
            int cursorX = 80, cursorY = 4;
            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
            Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            Console.SetCursorPosition(cursorX, cursorY);
            Console.Write("Round    : {0} (", round);
            printASCII(players[player].name, encoder);
            Console.Write(")     ");
            Console.SetCursorPosition(cursorX, cursorY + 2);
            Console.Write("Seq. Pass: {0}", numOfPass);
            Console.SetCursorPosition(cursorX, cursorY + 4);
            Console.Write("Returns  :");
            Console.SetCursorPosition(cursorX, cursorY + 6);
            Console.Write("Query    :");
            cursorX = 2; cursorY = 5;
            Console.SetCursorPosition(cursorX, cursorY + 6);
            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
            for (int i = 0; i < 25; i++) Console.Write((char)196);
            for (int j = 0; j < 2; j++)
            {
                cursorY += 8 * j;
                Console.SetCursorPosition(cursorX, cursorY);
                printASCII(players[j].name, encoder);
                Console.SetCursorPosition(cursorX, cursorY + 2);
                Console.Write("Bag: ");
                Console.ForegroundColor = themes[settings.theme].BagForeGroung;
                for (int i = 0; i < players[j].bag.Length; i++)
                {
                    if (player == j)
                    {
                        Console.Write(" {0}", players[j].bag[i]);
                    }
                    else
                    {
                        Console.Write(" {0}", (char)219);
                    }
                }
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                Console.SetCursorPosition(cursorX, cursorY + 4);
                Console.WriteLine("Score: {0}", players[j].score);
            }
            cursorX = 30; cursorY = 2;
            for (int i = 0; i < gameboard.Length; i++)
            {
                Console.SetCursorPosition(cursorX, cursorY + i);
                for (int j = 0; j < gameboard[i].Length; j++)
                {
                    if (gameboard[i][j].highLighted)
                    {
                        Console.BackgroundColor = themes[settings.theme].HighlightedBackGround;
                        gameboard[i][j].highLighted = false;
                    }
                    Console.Write(gameboard[i][j].cell);
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                }
            }
            Console.SetCursorPosition(0, 46);
            for (int i = 0; i < Console.BufferWidth; i++) Console.Write((char)196);
            Console.SetCursorPosition(1, 47);
            Console.Write("Letter Points:  ");
            cursorX = Console.CursorLeft;
            cursorY = Console.CursorTop;
            for (int i = 0; i < letters[0].Length / 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Console.SetCursorPosition(cursorX + i * 5, cursorY + j);
                    Console.Write("{0}:{1}  ", letters[0][j * letters[0].Length / 2 + i], letters[1][j * letters[0].Length / 2 + i]);
                }
            }
        }
        static void printQuery(string queryStr, string[] dictionary)
        {
            int cursorX = 83, cursorY = 13;
            if (queryStr != null)
            {
                Console.SetCursorPosition(cursorX + 8, cursorY - 3);
                Console.Write("{0}             ", queryStr);
                string[] queryList = query(queryStr, dictionary, 10);
                for (int i = 0; i < queryList.Length; i++)
                {
                    Console.SetCursorPosition(cursorX, cursorY + i * 2);
                    Console.Write("{0}             ", queryList[i]);
                }
            }
        }
        static int select(string[] dictionary,ref int leftQuery,ref bool saved,GameSetting settings)
        {
            drawBox(25, 40, 58, 1, true, (int)' ');
            drawBox(24, 37, 60, 7, false, 177);
            int index = 0;
            while (true)
            {
                if (leftQuery == 0 && index == 0) index = 1;
                printSelections(index, leftQuery,settings);
                NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
                NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
                while (true)
                {
                    int key=0;
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown) key = record.KeyEvent.wVirtualKeyCode;
                    else if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0)
                            {
                                record = NativeMethods.RecordEvent(handle, record);
                            }
                            key = (int)ConsoleKey.Enter;
                        }
                        if (record.MouseEvent.dwMousePosition.Y < 42 && record.MouseEvent.dwMousePosition.Y > 38)
                        {
                            if (record.MouseEvent.dwMousePosition.X > 25 && record.MouseEvent.dwMousePosition.X < 38 && index != 0 && leftQuery > 0)
                            {
                                index = 0; printSelections(index, leftQuery,settings);
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 39 && record.MouseEvent.dwMousePosition.X < 56 && index != 1)
                            {
                                index = 1; printSelections(index, leftQuery,settings);
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 57 && record.MouseEvent.dwMousePosition.X < 69 && index != 2)
                            {
                                index = 2; printSelections(index, leftQuery,settings);
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 69 && record.MouseEvent.dwMousePosition.X < 81 && index != 3)
                            {
                                index = 3; printSelections(index, leftQuery,settings);
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 4 && record.MouseEvent.dwMousePosition.X < 21 && index != 4)
                            {
                                index = 4; printSelections(index, leftQuery,settings);
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 86 && record.MouseEvent.dwMousePosition.X < 98 && index != 5)
                            {
                                index = 5; printSelections(index, leftQuery,settings);
                            }
                        }
                    }
                    else continue;
                    if (key == (int)ConsoleKey.Enter)
                    {
                        Console.SetCursorPosition(91, 8);
                        Console.Write("             ");
                        if (index == 0)
                        {
                            drawBox(25, 40, 58, 1, false, (int)' ');
                            Console.SetCursorPosition(30, 40);
                            Console.Write("The word to be query: ");
                            int maxLength = 15;
                            char[] queryChr = new char[maxLength + 1];
                            while (true)
                            {
                                record = NativeMethods.RecordEvent(handle, record);
                                int tempKey = 0;
                                if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                                {
                                    tempKey = record.KeyEvent.wVirtualKeyCode;
                                    if (tempKey <= 'z' && tempKey >= 'a') tempKey -= (char)((int)'a' - (int)'A');
                                    if (tempKey == 'İ' || tempKey == 'ı') tempKey = 'I';
                                    if (tempKey == 190) tempKey = (int)'.';
                                    if (maxLength > 0 && ((tempKey <= 'Z' && tempKey >= 'A') || tempKey == '.'))
                                    {
                                        Console.Write((char)tempKey);
                                        queryChr[15 - maxLength] = (char)tempKey;
                                        maxLength--;
                                    }
                                    else if ((int)ConsoleKey.Backspace == tempKey && maxLength < 15)
                                    {
                                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                        Console.Write(' ');
                                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                        maxLength++;
                                        queryChr[15 - maxLength] = '\0';
                                    }
                                }
                                else if (record.EventType == NativeMethods.MOUSE_EVENT && record.MouseEvent.dwButtonState == 1)
                                {
                                    while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                                    tempKey = (int)ConsoleKey.Enter;
                                }
                                else continue;
                                if ((int)ConsoleKey.Enter == tempKey)
                                {
                                    int i = 0;
                                    while (queryChr[i] != '\0') i++;
                                    string queryStr = new string(queryChr, 0, i);
                                    if (queryStr.Length > 1)
                                    {
                                        saved = false;
                                        leftQuery--;
                                        printQuery(queryStr, dictionary);
                                        Console.SetCursorPosition(83, 34);
                                        Console.Write("Left Query: {0}", leftQuery);
                                    }
                                    break;
                                }
                            }
                            drawBox(25, 40, 58, 1, true, (int)' '); break;
                        }
                        else
                        {
                            printQuery("", dictionary);
                            Console.SetCursorPosition(83, 34);
                            Console.Write("                 ", leftQuery); return index;
                        }
                    }
                    else if ((int)ConsoleKey.LeftArrow == key && index > 0 && index < 4)
                    {
                        if (leftQuery > 0 || index > 1) index--; break;
                    }
                    else if (key == (int)ConsoleKey.RightArrow && index < 3)
                    {
                        index++; break;
                    }
                    else if (key == (int)ConsoleKey.Tab)
                    {
                        if (index == 4)
                        {
                            index = 5; break;
                        }
                        else if(index==5)
                        {
                            index = 0; break;
                        }
                        index = 4; break;
                    }
                }
            }
        }
        static void printSelections(int index, int leftQuery,GameSetting settings)
        {
            if (index == 0)
            {
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
            }
            else
            {
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            }
            Console.SetCursorPosition(26, 40);
            if (leftQuery > 0) Console.Write(" Query Word ");
            if (index == 1)
            {
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
            }
            else
            {
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            }
            Console.SetCursorPosition(40, 40);
            Console.Write(" Change Letters ");
            if (index == 2)
            {
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
            }
            else
            {
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            }
            Console.SetCursorPosition(58, 40);
            Console.Write(" Pass Turn ");
            if (index == 3)
            {
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
            }
            else
            {
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            }
            Console.SetCursorPosition(70, 40);
            Console.Write(" Form Word ");
            if (index == 4)
            {
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
            }
            else
            {
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            }
            Console.SetCursorPosition(5, 40);
            Console.Write(" Return to Menu ");
            if (index == 5)
            {
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
            }
            else
            {
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
            }
            Console.SetCursorPosition(87, 40);
            Console.Write(" Save Game ");
            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
        }
        static bool changeLetters(Player player, string[][] letters, Random rand, GameSetting settings)
        {
            int row, col = 8, cursorIndex = 0, cursorIndexOld = 0, tempIndex = 0, howMany = 0;
            bool[] selected = new bool[7];
            bool notEnough = false;
            for (int i = 0; i < 7; i++) selected[i] = false;
            if (player.number == 1) row = 7; else row = 15;
            drawBox(24, 37, 60, 7, true, (int)' ');
            drawBox(24, 37, 60, 7, false, 177);
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            while (true)
            {
                cursorIndex = printSelected(cursorIndex, row, player.bag, selected,settings);
                if (notEnough)
                {
                    Console.SetCursorPosition(26, 40);
                    Console.Write(" [CANCEL]    [DONE]   Not enough letter(s)");
                }
                else
                {
                    Console.SetCursorPosition(26, 40);
                    Console.Write(" [CANCEL]    [DONE]   Choose the letter(s) to change");
                }
                if (cursorIndex == 7)
                {
                    Console.SetCursorPosition(26, 40);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [CANCEL] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                if (cursorIndex == 8)
                {
                    Console.SetCursorPosition(38, 40);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [DONE] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                while (true)
                {
                    int key = 0;
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown) key = record.KeyEvent.wVirtualKeyCode;
                    else if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                            key = key = (int)ConsoleKey.Enter;
                        }
                        if (record.MouseEvent.dwMousePosition.Y < 42 && record.MouseEvent.dwMousePosition.Y > 38)
                        {
                            if (record.MouseEvent.dwMousePosition.X > 25 && record.MouseEvent.dwMousePosition.X < 36 && cursorIndex != 7)
                            {
                                cursorIndex = 7; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 37 && record.MouseEvent.dwMousePosition.X < 46 && cursorIndex != 8)
                            {
                                cursorIndex = 8; break;
                            }
                        }
                        else if (record.MouseEvent.dwMousePosition.Y < row+2 && record.MouseEvent.dwMousePosition.Y > row-2)
                        {
                            if (record.MouseEvent.dwMousePosition.X > 7 && record.MouseEvent.dwMousePosition.X < 21)
                            {
                                for (int i = 0; i < 7; i++)
                                    if (record.MouseEvent.dwMousePosition.X == (col + i * 2))
                                    {
                                        cursorIndexOld = cursorIndex;
                                        cursorIndex = i;
                                        break;
                                    }
                                if (cursorIndexOld != cursorIndex) break;
                            }
                        }
                    }
                    else continue;
                    if (cursorIndex < 7)
                    {
                        if (key == (int)ConsoleKey.Enter)
                        {
                            if (!selected[cursorIndex])
                            {
                                selected[cursorIndex] = true;
                                tempIndex++;
                                cursorIndex = 0;
                            } break;
                        }
                        else if (key == (int)ConsoleKey.LeftArrow && cursorIndex > 0)
                        {
                            int temp = cursorIndex;
                            do cursorIndex--; while (selected[cursorIndex] && cursorIndex > 0);
                            if (cursorIndex == 0 && selected[0]) cursorIndex = temp + 1; break;
                        }
                        else if (key == (int)ConsoleKey.RightArrow && cursorIndex < 6)
                        {
                            cursorIndex++; break;
                        }
                        else if (key == (int)ConsoleKey.DownArrow)
                        {
                            cursorIndex = 7; break;
                        }
                        else if (key == (int)ConsoleKey.Escape) return false;
                    }
                    if (key == (int)ConsoleKey.UpArrow)
                    {
                        cursorIndex = 0; break;
                    }
                    else if (key == (int)ConsoleKey.LeftArrow && cursorIndex==8)
                    {
                        cursorIndex=7; break;
                    }
                    else if (key == (int)ConsoleKey.RightArrow && cursorIndex == 7)
                    {
                        cursorIndex=8; break;
                    }
                    else if (key == (int)ConsoleKey.Enter)
                    {
                        if (cursorIndex == 7) return false;
                        else
                        {
                            char[] tempBag = (char[])player.bag.Clone();
                            howMany = reservoirLetters(letters);
                            int marked = 0;
                            for (int i = 0; i < selected.Length; i++) if (selected[i]) marked++;
                            if (marked > howMany)
                            {
                                cursorIndex = 0;
                                for (int i = 0; i < selected.Length; i++) selected[i] = false;
                                notEnough = true;
                                break;
                            }
                            removeFromBag(player.bag, selected);
                            if (fillBag(player.bag, letters, rand) == 0) break;
                            addToResevoir(tempBag, selected, letters);
                            int position = 91;
                            for (int i = 0; i < 7; i++)
                                if (selected[i])
                                {
                                    Console.SetCursorPosition(position, 8);
                                    Console.Write(tempBag[i]);
                                    position += 2;
                                }
                            Console.Write("            "); return true;
                        }
                    }
                }
            }
        }
        static int formWord(GameSetting settings, Player[] players, int player, GameboardCell[][] gameboard, string[] dictionary, string[][] letters, ref bool saved,Random rand) 
        {
            WordInfo wordPlaceInfo = new WordInfo();
            wordPlaceInfo.startX = int.MaxValue;
            wordPlaceInfo.startY = int.MaxValue;
            wordPlaceInfo.endX = int.MinValue;
            wordPlaceInfo.endY = int.MinValue;
            LetterInfo[] lettersInfo = new LetterInfo[7];
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            Coord[] places = new Coord[2];
            Coord place; int isHorizontal = 0;
            GameboardCell[][] copyOfTheGameboard = createGameboard(33, 48);
            copyGameboard(gameboard, copyOfTheGameboard);
            int row, col = 8;
            bool[] selected = new bool[7];
            int cursorIndex = 0, cursorIndexOld = 0, key = 0;
            if (players[player].number == 1) row = 7; else row = 15;
            for (int i = 0; i < 7; i++) selected[i] = false;
            drawBox(24, 37, 60, 7, true, (int)' ');
            drawBox(24, 37, 60, 7, false, 177);
            while (true)
            {
                cursorIndex = printSelected(cursorIndex, row, players[player].bag, selected,settings);
                Console.SetCursorPosition(27, 40);
                Console.Write(" [CANCLE]    [RESET]    [DONE]      Form a word");
                if (cursorIndex == 7)
                {
                    Console.SetCursorPosition(27, 40);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [CANCLE] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (cursorIndex == 8)
                {
                    Console.SetCursorPosition(39, 40);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [RESET] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (cursorIndex == 9)
                {
                    Console.SetCursorPosition(50, 40);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [DONE] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                while (true)
                {
                    key = 0;
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown) key = record.KeyEvent.wVirtualKeyCode;
                    else if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                            key = (int)ConsoleKey.Enter;
                        }
                        if (record.MouseEvent.dwMousePosition.Y < row + 2 && record.MouseEvent.dwMousePosition.Y > row - 2)
                        {
                            if (record.MouseEvent.dwMousePosition.X > 7 && record.MouseEvent.dwMousePosition.X < 21)
                            {
                                for (int i = 0; i < 7; i++)
                                    if ((!selected[i]) && record.MouseEvent.dwMousePosition.X == col + i * 2)
                                    {
                                        cursorIndexOld = cursorIndex; cursorIndex = i;
                                        printSelected(cursorIndex, row, players[player].bag, selected,settings);
                                    }
                                if (cursorIndexOld != cursorIndex) break;
                            }
                        }
                        else if (record.MouseEvent.dwMousePosition.Y < 42 && record.MouseEvent.dwMousePosition.Y > 38)
                        {
                            if (record.MouseEvent.dwMousePosition.X > 26 && record.MouseEvent.dwMousePosition.X < 37 && cursorIndex != 7)
                            {
                                cursorIndex = 7; printSelected(cursorIndex, row, players[player].bag, selected,settings); break;
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 38 && record.MouseEvent.dwMousePosition.X < 48 && cursorIndex != 8)
                            {
                                cursorIndex = 8; printSelected(cursorIndex, row, players[player].bag, selected,settings); break;
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 49 && record.MouseEvent.dwMousePosition.X < 58 && cursorIndex != 9)
                            {
                                cursorIndex = 9; printSelected(cursorIndex, row, players[player].bag, selected,settings); break;
                            }
                        }
                    }
                    else continue;
                    if (cursorIndex < 7)
                    {
                        if (key == (int)ConsoleKey.Enter)
                        {
                            selected[cursorIndex] = true; key = 0;
                            if (places[0].gameboardCol == 0)
                            {
                                place = selectPlace(gameboard, isHorizontal, places[0],settings);
                                if (place.gameboardCol == -1)
                                {
                                    selected[cursorIndex] = false; break;
                                } places[0] = place;
                            }
                            else if (places[1].gameboardCol == 0)
                            {
                                place = selectPlace(gameboard, isHorizontal, places[0],settings);
                                if (place.gameboardCol == -1)
                                {
                                    selected[cursorIndex] = false; break;
                                } places[1] = place;
                                if (places[0].gameboardCol == places[1].gameboardCol) isHorizontal = 2;
                                else if (places[0].gameboardRow == places[1].gameboardRow) isHorizontal = 1;
                            }
                            else
                            {
                                place = selectPlace(gameboard, isHorizontal, places[1],settings);
                                if (place.gameboardCol == -1)
                                {
                                    selected[cursorIndex] = false; break;
                                }
                            }
                            if (place.gameboardCol < wordPlaceInfo.startX) wordPlaceInfo.startX = place.gameboardCol;
                            if (place.gameboardCol > wordPlaceInfo.endX) wordPlaceInfo.endX = place.gameboardCol;
                            if (place.gameboardRow < wordPlaceInfo.startY) wordPlaceInfo.startY = place.gameboardRow;
                            if (place.gameboardRow > wordPlaceInfo.endY) wordPlaceInfo.endY = place.gameboardRow;
                            lettersInfo[cursorIndex].X = place.gameboardCol;
                            lettersInfo[cursorIndex].Y = place.gameboardRow;
                            Console.SetCursorPosition(place.screenX, place.screenY);
                            Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                            Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                            Console.Write(players[player].bag[cursorIndex]);
                            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                            Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                            gameboard[place.gameboardY][place.gameboardX].cell = players[player].bag[cursorIndex];
                            cursorIndex = 0; break;
                        }
                        else if (key == (int)ConsoleKey.LeftArrow && cursorIndex > 0)
                        {
                            int temp = cursorIndex;
                            do cursorIndex--; while (selected[cursorIndex] && cursorIndex > 0);
                            if (cursorIndex == 0 && selected[0]) cursorIndex = temp + 1; break;
                        }
                        else if (key == (int)ConsoleKey.RightArrow && cursorIndex < 6)
                        {
                            cursorIndex++; break;
                        }
                        else if (key == (int)ConsoleKey.DownArrow)
                        {
                            cursorIndex = 7; break;
                        }
                        else if (key == (int)ConsoleKey.Escape)
                        {
                            copyGameboard(copyOfTheGameboard, gameboard); return 3;
                        }
                    }
                    else if (key == (int)ConsoleKey.UpArrow)
                    {
                        cursorIndex = 0; break;
                    }
                    else if (key == (int)ConsoleKey.LeftArrow && cursorIndex > 7)
                    {
                        cursorIndex--; break;
                    }
                    else if (key == (int)ConsoleKey.RightArrow && cursorIndex < 9)
                    {
                        cursorIndex++; break;
                    }
                    else if (key == (int)ConsoleKey.Enter)
                    {
                        if (cursorIndex == 7)
                        {
                            copyGameboard(copyOfTheGameboard, gameboard); return 3;
                        }
                        else if (cursorIndex == 8)
                        {
                            copyGameboard(copyOfTheGameboard, gameboard); return 4;
                        }
                        else if (cursorIndex == 9)
                        {
                            saved = false;
                            if (acceptable(lettersInfo, wordPlaceInfo, isHorizontal, players, player, selected, gameboard, dictionary, letters))
                            {
                                removeFromBag(players[player].bag, selected);
                                fillBag(players[player].bag, letters, rand); return 1;
                            }
                            else
                            {
                                copyGameboard(copyOfTheGameboard, gameboard); return 2;
                            }
                        }
                    }
                }
            }
        }
        static int printSelected(int cursorIndex, int row, char[] bag, bool[] selected,GameSetting settings)
        {
            int col = 8;
            for (int i = 0; i < 7; i++)
            {
                if (selected[i])
                {
                    if (cursorIndex == i) cursorIndex++;
                    Console.SetCursorPosition(col + i * 2, row);
                    Console.BackgroundColor = themes[settings.theme].SelectedBackGround;
                    Console.ForegroundColor = themes[settings.theme].SelectedForeground;
                    Console.Write(bag[i]);
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else
                {
                    Console.SetCursorPosition(col + i * 2, row); Console.Write(bag[i]);
                }
                if (cursorIndex == i)
                {
                    Console.SetCursorPosition(col + i * 2, row);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(bag[i]);
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
            }
            return cursorIndex;
        }
        static Coord selectPlace(GameboardCell[][] gameboard, int direction, Coord old,GameSetting settings)
        {
            Coord place = new Coord();
            int cursorX = 1, cursorY = 1;
            if (old.gameboardRow == 0)
            {
                for (int i = 0; i < 15; i++)
                {
                    bool flag = false;
                    for (int j = 0; j < 15; j++)
                    {
                        if (gameboard[(i + 1) * 2][(j + 1) * 3].cell == '\0')
                        {
                            cursorX = j + 1; cursorY = i + 1; flag = true; break;
                        }
                    }
                    if (flag) break;
                }
            }
            else if (direction == 0)
            {
                cursorX = old.gameboardCol; cursorY = old.gameboardRow;
                for (int i = 0; i < 15; i++)
                {
                    cursorX++; if (cursorX > 15) cursorX = 1;
                    if (gameboard[cursorY * 2][cursorX * 3].cell == '\0') break;
                }
            }
            else
            {
                cursorX = old.gameboardCol; cursorY = old.gameboardRow;
                if (direction == 1)
                {
                    for (int i = 0; i < 15; i++)
                    {
                        cursorX++; if (cursorX > 15) cursorX = 1;
                        if (gameboard[cursorY * 2][cursorX * 3].cell == '\0') break;
                    }
                }
                else if (direction == 2)
                {
                    for (int i = 0; i < 15; i++)
                    {
                        cursorY++; if (cursorY > 15) cursorY = 1;
                        if (gameboard[cursorY * 2][cursorX * 3].cell == '\0') break;
                    }
                }
            }
            int gameboardStartX = 30, gameboardStartY = 2, key = 0;
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            while (true)
            {
                Console.SetCursorPosition(gameboardStartX + cursorX * 3, gameboardStartY + cursorY * 2);
                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                Console.Write(gameboard[cursorY * 2][cursorX * 3].cell);
                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                while (true)
                {
                    key = 0; record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown) key = record.KeyEvent.wVirtualKeyCode;
                    else if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                            key = (int)ConsoleKey.Enter;
                        }
                        bool flag = false;
                        if (direction == 0 && old.gameboardCol == 0) flag = true;
                        else if (direction == 0)
                        {
                            if (old.screenX == record.MouseEvent.dwMousePosition.X || old.screenY == record.MouseEvent.dwMousePosition.Y) flag = true;
                            else if (old.screenX - 1 == record.MouseEvent.dwMousePosition.X) flag = true;
                        }
                        else if (direction == 2 && (old.screenX == record.MouseEvent.dwMousePosition.X || old.screenX - 1 == record.MouseEvent.dwMousePosition.X)) flag = true;
                        else if (direction == 1 && (old.screenY == record.MouseEvent.dwMousePosition.Y)) flag = true;
                        if (flag)
                        {
                            for (int i = 1; i <= 15; i++)
                                for (int j = 1; j <= 15; j++)
                                    if (gameboard[i * 2][j * 3].cell == '\0')
                                        if (record.MouseEvent.dwMousePosition.X == gameboardStartX + j * 3 || (record.MouseEvent.dwMousePosition.X == gameboardStartX + j * 3 - 1))
                                            if (record.MouseEvent.dwMousePosition.Y == gameboardStartY + i * 2)
                                            {
                                                Console.SetCursorPosition(gameboardStartX + cursorX * 3, gameboardStartY + cursorY * 2);
                                                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                                                Console.Write(gameboard[cursorY * 2][cursorX * 3].cell);
                                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                                                cursorX = j; cursorY = i; break;
                                            }
                        }
                    }
                    else continue;

                    Console.SetCursorPosition(gameboardStartX + cursorX * 3, gameboardStartY + cursorY * 2);
                    Console.Write(gameboard[cursorY * 2][cursorX * 3].cell);
                    if (key == (int)ConsoleKey.Enter)
                    {
                        int x = record.MouseEvent.dwMousePosition.X, y = record.MouseEvent.dwMousePosition.Y;
                        if((x<30||x>77||y<2||y>34)&&record.EventType==NativeMethods.MOUSE_EVENT)
                        {
                            place.gameboardCol = -1; return place;
                        }
                        place.gameboardCol = cursorX;
                        place.gameboardRow = cursorY;
                        place.screenX = gameboardStartX + cursorX * 3;
                        place.screenY = gameboardStartY + cursorY * 2;
                        place.gameboardX = cursorX * 3;
                        place.gameboardY = cursorY * 2; return place;
                    }
                    else if (key == (int)ConsoleKey.LeftArrow)
                    {
                        if ((direction == 0 && old.gameboardCol == 0) || direction == 1) do { cursorX--; if (cursorX < 1) cursorX = 15; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        else if (direction == 0 && old.gameboardCol != 0)
                        {
                            cursorY = old.gameboardRow;
                            do { cursorX--; if (cursorX < 1) cursorX = 15; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        }
                    }
                    else if (key == (int)ConsoleKey.RightArrow)
                    {
                        if ((direction == 0 && old.gameboardCol == 0) || direction == 1) do { cursorX++; if (cursorX > 15) cursorX = 1; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        else if (direction == 0 && old.gameboardCol != 0)
                        {
                            cursorY = old.gameboardRow; do { cursorX++; if (cursorX > 15) cursorX = 1; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        }
                    }
                    else if (key == (int)ConsoleKey.UpArrow)
                    {
                        if ((direction == 0 && old.gameboardCol == 0) || direction == 2) do { cursorY--; if (cursorY < 1) cursorY = 15; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        else if (direction == 0 && old.gameboardCol != 0)
                        {
                            cursorX = old.gameboardCol;
                            do { cursorY--; if (cursorY < 1) cursorY = 15; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        }
                    }
                    else if (key == (int)ConsoleKey.DownArrow)
                    {
                        if ((direction == 0 && old.gameboardCol == 0) || direction == 2) do { cursorY++; if (cursorY > 15) cursorY = 1; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        else if (direction == 0 && old.gameboardCol != 0)
                        {
                            cursorX = old.gameboardCol;
                            do { cursorY++; if (cursorY > 15) cursorY = 1; } while (gameboard[cursorY * 2][cursorX * 3].cell != '\0');
                        }
                    }
                    else if (key == (int)ConsoleKey.Escape) { place.gameboardCol = -1; return place; } break;
                }
            }
        }
        static void copyGameboard(GameboardCell[][] mainGameboard, GameboardCell[][] copyGameboard)
        {
            for (int i = 0; i < mainGameboard.Length; i++)
                for (int j = 0; j < mainGameboard[i].Length; j++)
                {
                    copyGameboard[i][j].cell = mainGameboard[i][j].cell;
                    copyGameboard[i][j].highLighted = mainGameboard[i][j].highLighted;
                }
        }
        static void removeFromBag(char[] bag, bool[] selected)
        {
            for (int i = 0; i < 7; i++) if (selected[i]) bag[i] = '\0';
        }
        static void addToResevoir(char[] bag, bool[] selected, string[][] letters)
        {
            for (int i = 0; i < 7; i++) if (selected[i]) for (int j = 0; j < letters[0].Length; j++) if (letters[0][j] == Convert.ToString(bag[i])) letters[2][j] = Convert.ToString(Convert.ToInt32(letters[2][j]) + 1);
        }
        static bool acceptable(LetterInfo[] lettersInfo, WordInfo wordPlaceInfo, int direction, Player[] players, int player, bool[] selected, GameboardCell[][] gameboard, string[] dictionary, string[][] letters)
        {
            if (direction == 1)
            {
                string wordStr = makeStringH(wordPlaceInfo, gameboard, dictionary);
                if (wordStr != null && isExist(wordStr, dictionary))
                {
                    players[player].score += calculatePoint(wordStr, letters);
                    for (int i = 0; i < 7; i++)
                        if (selected[i])
                        {
                            WordInfo tempWordInfo = new WordInfo();
                            tempWordInfo.startX = lettersInfo[i].X;
                            tempWordInfo.startY = lettersInfo[i].Y;
                            tempWordInfo.endX = lettersInfo[i].X;
                            tempWordInfo.endY = lettersInfo[i].Y;
                            string wordStrV = makeStringV(tempWordInfo, gameboard, dictionary);
                            if (wordStrV != null && isExist(wordStrV, dictionary)) players[player].score += calculatePoint(wordStrV, letters);
                        } return true;
                }
                else return false;
            }
            else if (direction == 2)
            {
                string wordStr = makeStringV(wordPlaceInfo, gameboard, dictionary);
                if (isExist(wordStr, dictionary))
                {
                    players[player].score += calculatePoint(wordStr, letters);
                    for (int i = 0; i < 7; i++)
                        if (selected[i])
                        {
                            WordInfo tempWordInfo = new WordInfo();
                            tempWordInfo.startX = lettersInfo[i].X;
                            tempWordInfo.startY = lettersInfo[i].Y;
                            tempWordInfo.endX = lettersInfo[i].X;
                            tempWordInfo.endY = lettersInfo[i].Y;
                            string wordStrH = makeStringH(tempWordInfo, gameboard, dictionary);
                            if (wordStrH != null && isExist(wordStrH, dictionary)) players[player].score += calculatePoint(wordStrH, letters);
                        } return true;
                }
                else return false;
            }
            else
            {
                for (int i = 0; i < 7; i++)
                    if (selected[i])
                    {
                        WordInfo tempWordInfo = new WordInfo();
                        tempWordInfo.startX = lettersInfo[i].X;
                        tempWordInfo.startY = lettersInfo[i].Y;
                        tempWordInfo.endX = lettersInfo[i].X;
                        tempWordInfo.endY = lettersInfo[i].Y;
                        string wordStrH = makeStringH(tempWordInfo, gameboard, dictionary);
                        string wordStrV = makeStringV(tempWordInfo, gameboard, dictionary);
                        if (wordStrH == null && wordStrV == null) return false;
                        if (wordStrH != null && isExist(wordStrH, dictionary)) players[player].score += calculatePoint(wordStrH, letters);
                        if (wordStrV != null && isExist(wordStrV, dictionary)) players[player].score += calculatePoint(wordStrV, letters); return true;
                    }
            } return false;
        }
        static string makeStringH(WordInfo wordPlaceInfo, GameboardCell[][] gameboard, string[] dictionary)
        {
            int row = wordPlaceInfo.startY;
            while (wordPlaceInfo.startX > 1 && (gameboard[row * 2][(wordPlaceInfo.startX - 1) * 3].cell != '\0')) wordPlaceInfo.startX--;
            while (wordPlaceInfo.endX < 15 && (gameboard[row * 2][(wordPlaceInfo.endX + 1) * 3].cell != '\0')) wordPlaceInfo.endX++;
            int length = wordPlaceInfo.endX - wordPlaceInfo.startX + 1;
            if (length < 2) return null;
            char[] wordChr = new char[length];
            for (int i = 0; i < length; i++)
            {
                if (gameboard[row * 2][(wordPlaceInfo.startX + i) * 3].cell == '\0')return null;
                else wordChr[i] = gameboard[row * 2][(wordPlaceInfo.startX + i) * 3].cell;
            }
            string finalStr = new string(wordChr);
            if (isExist(finalStr, dictionary))
            {
                for (int i = wordPlaceInfo.startX * 3 - 1; i < wordPlaceInfo.endX * 3 + 1; i++) gameboard[row * 2][i].highLighted = true; return finalStr;
            } return null;
        }
        static string makeStringV(WordInfo wordPlaceInfo, GameboardCell[][] gameboard, string[] dictionary)
        {
            int col = wordPlaceInfo.startX;
            while (wordPlaceInfo.startY > 1 && (gameboard[(wordPlaceInfo.startY - 1) * 2][col * 3].cell != '\0')) wordPlaceInfo.startY--;
            while (wordPlaceInfo.endY < 15 && (gameboard[(wordPlaceInfo.endY + 1) * 2][col * 3].cell != '\0')) wordPlaceInfo.endY++;
            int length = wordPlaceInfo.endY - wordPlaceInfo.startY + 1;
            if (length < 2) return null;
            char[] wordChr = new char[length];
            for (int i = 0; i < length; i++)
            {
                if (gameboard[(wordPlaceInfo.startY + i) * 2][col * 3].cell == '\0') return null;
                else wordChr[i] = gameboard[(wordPlaceInfo.startY + i) * 2][col * 3].cell;
            }
            string finalStr = new string(wordChr);
            if (isExist(finalStr, dictionary))
            {
                for (int i = wordPlaceInfo.startY * 2; i < wordPlaceInfo.endY * 2 + 1; i++) gameboard[i][col * 3].highLighted = true; return finalStr;
            } return null;
        }
        static int menu(Encoding encoder, GameSetting settings, bool oldGameExist,string[] helpTxt)
        {
            int index = 1;
            GameboardCell[][] board1 = createGameboard(45, 36);
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            board1[3 * 2][4 * 3].cell = 'M'; board1[3 * 2][5 * 3].cell = 'E'; board1[3 * 2][6 * 3].cell = 'N'; board1[3 * 2][7 * 3].cell = 'U';
            board1[6 * 2][2 * 3].cell = (char)16; board1[6 * 2][3 * 3].cell = 'P'; board1[6 * 2][4 * 3].cell = 'L'; board1[6 * 2][5 * 3].cell = 'A'; board1[6 * 2][6 * 3].cell = 'Y';
            board1[8 * 2][2 * 3].cell = (char)15; board1[8 * 2][3 * 3].cell = 'S'; board1[8 * 2][4 * 3].cell = 'E'; board1[8 * 2][5 * 3].cell = 'T'; board1[8 * 2][6 * 3].cell = 'T';
            board1[8 * 2][7 * 3].cell = 'I'; board1[8 * 2][8 * 3].cell = 'N'; board1[8 * 2][9 * 3].cell = 'G'; board1[8 * 2][10 * 3].cell = 'S';
            board1[10 * 2][2 * 3].cell = '?'; board1[10 * 2][3 * 3].cell = 'H'; board1[10 * 2][4 * 3].cell = 'E'; board1[10 * 2][5 * 3].cell = 'L'; board1[10 * 2][6 * 3].cell = 'P';
            board1[12 * 2][2 * 3].cell = 'x'; board1[12 * 2][3 * 3].cell = 'E'; board1[12 * 2][4 * 3].cell = 'X'; board1[12 * 2][5 * 3].cell = 'I'; board1[12 * 2][6 * 3].cell = 'T';
            while (true)
            {
                drawMenuScreen(settings);
                if (index == 1) for (int i = 8; i < 19; i++) board1[12][i].highLighted = true;
                else if (index == 2) for (int i = 8; i < 31; i++) board1[16][i].highLighted = true;
                else if (index == 3) for (int i = 8; i < 19; i++) board1[20][i].highLighted = true;
                else if (index == 4) for (int i = 8; i < 19; i++) board1[24][i].highLighted = true;
                for (int i = 0; i < board1[0].Length; i++) for (int j = 0; j < board1.Length; j++)
                    {
                        Console.SetCursorPosition(58 + i, 2 + j);
                        if (board1[j][i].highLighted)
                        {
                            board1[j][i].highLighted = false;
                            Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                            Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                            Console.Write(board1[j][i].cell);
                            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                            Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                        }
                        else Console.Write(board1[j][i].cell);
                    }
                while (true)
                {
                    bool flag = false; int tempChar = 0;
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record); tempChar = (int)ConsoleKey.Enter;
                        }
                        if (record.MouseEvent.dwMousePosition.X > 65 && record.MouseEvent.dwMousePosition.X < 92 && record.MouseEvent.dwButtonState == 0)
                        {
                            if (record.MouseEvent.dwMousePosition.Y < 16 && record.MouseEvent.dwMousePosition.Y > 12 && index != 1)
                            {
                                index = 1; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 20 && record.MouseEvent.dwMousePosition.Y > 16 && index != 2)
                            {
                                index = 2; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 24 && record.MouseEvent.dwMousePosition.Y > 20 && index != 3)
                            {
                                index = 3; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 28 && record.MouseEvent.dwMousePosition.Y > 24 && index != 4)
                            {
                                index = 4; break;
                            }
                        }
                    }
                    else if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                    {
                        tempChar = record.KeyEvent.wVirtualKeyCode;
                        if (tempChar == (int)ConsoleKey.UpArrow && index > 1)
                        {
                            index--; break;
                        }
                        else if (tempChar == (int)ConsoleKey.DownArrow && index < 4)
                        {
                            index++; break;
                        }
                    }
                    if (tempChar == (int)ConsoleKey.Enter)
                    {
                        if (index == 4)
                        {
                            if (exit(settings)) return 0; Console.Clear(); break;
                        }
                        else if (index == 1)
                        {
                            int tempIndex = 1, tempKey = 0;
                            if (oldGameExist)
                            {
                                drawBox(42, 15, 25, 15, true, ' ');
                                drawBox(42, 15, 25, 15, false, (char)177);
                                while (true)
                                {
                                    if (tempIndex == 1)
                                    {
                                        Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                        Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                                    }
                                    else
                                    {
                                        Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                        Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                                    }
                                    Console.SetCursorPosition(49, 20);
                                    Console.Write(" Load Game ");
                                    if (tempIndex == 2)
                                    {
                                        Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                        Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                                    }
                                    else
                                    {
                                        Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                        Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                                    }
                                    Console.SetCursorPosition(49, 23);
                                    Console.Write(" New Game ");
                                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                    while (true)
                                    {
                                        record = NativeMethods.RecordEvent(handle, record);
                                        if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                                        {
                                            tempKey = (int)record.KeyEvent.wVirtualKeyCode;
                                            if (tempKey == (int)ConsoleKey.UpArrow && tempIndex > 1)
                                            {
                                                tempIndex--; break;
                                            }
                                            else if (tempKey == (int)ConsoleKey.DownArrow && tempIndex < 2)
                                            {
                                                tempIndex++; break;
                                            }
                                        }
                                        else if (record.EventType == NativeMethods.MOUSE_EVENT)
                                        {
                                            if (record.MouseEvent.dwButtonState == 1)
                                            {
                                                while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                                                tempKey = (int)ConsoleKey.Enter;
                                            }
                                            if (record.MouseEvent.dwButtonState == 0)
                                            {
                                                if (record.MouseEvent.dwMousePosition.X > 48 && record.MouseEvent.dwMousePosition.X < 61)
                                                {
                                                    if (record.MouseEvent.dwMousePosition.Y < 22 && record.MouseEvent.dwMousePosition.Y > 18 && tempIndex != 1)
                                                    {
                                                        tempIndex = 1; break;
                                                    }
                                                    else if (record.MouseEvent.dwMousePosition.Y < 25 && record.MouseEvent.dwMousePosition.Y > 21 && tempIndex != 2)
                                                    {
                                                        tempIndex = 2; break;
                                                    }
                                                }
                                            }
                                        }
                                        if (tempKey == (int)ConsoleKey.Enter)
                                        {
                                            if (record.EventType == NativeMethods.MOUSE_EVENT)
                                            {
                                                if (record.MouseEvent.dwMousePosition.Y < 15 || record.MouseEvent.dwMousePosition.Y > 29 || record.MouseEvent.dwMousePosition.X < 42 || record.MouseEvent.dwMousePosition.X > 66)
                                                {
                                                    flag = true; break;
                                                }
                                            }
                                            if (tempIndex == 1) return 2;
                                            else return 1;
                                        }
                                        else if (tempKey == (int)ConsoleKey.Escape)
                                        {
                                            flag = true; break;
                                        }
                                    }
                                    if (flag)
                                    {
                                        Console.Clear(); break;
                                    }
                                }
                            }
                            else return 1;
                        }
                        else if (index == 2)
                        {
                            setting(settings, encoder);
                            settings = loadSettings(readFile("sets"));
                            break;
                        }
                        else if (index == 3)
                        {
                            help(encoder,settings,helpTxt); break;
                        }
                    }
                    if(flag)
                    {
                        flag = false; break;
                    }
                }
            }
        }
        static void drawMenuScreen(GameSetting settings)
        {
            GameboardCell[][] board = createGameboard(21, 33);
            GameboardCell[][] board2 = createGameboard(21, 33);
            board[6 * 2][8 * 3].cell = 'M'; board[6 * 2][7 * 3].cell = 'A'; board[6 * 2][6 * 3].cell = 'G'; board[5 * 2][4 * 3].cell = 'W'; board[4 * 2][4 * 3].cell = 'O';
            board[7 * 2][9 * 3].cell = 'R'; board[6 * 2][9 * 3].cell = 'E'; board[5 * 2][9 * 3].cell = 'T'; board[4 * 2][9 * 3].cell = 'T'; board[2 * 2][9 * 3].cell = 'L';
            board[3 * 2][9 * 3].cell = 'E'; board[3 * 2][8 * 3].cell = 'L'; board[3 * 2][7 * 3].cell = 'B'; board[3 * 2][6 * 3].cell = 'B'; board[3 * 2][5 * 3].cell = 'I';
            board[3 * 2][4 * 3].cell = 'R'; board[3 * 2][3 * 3].cell = 'C'; board[3 * 2][2 * 3].cell = 'S'; board2[2 * 2][2 * 3].cell = 'W'; board2[2 * 2][3 * 3].cell = 'R';
            board2[2 * 2][4 * 3].cell = 'I'; board2[2 * 2][5 * 3].cell = 'T'; board2[2 * 2][6 * 3].cell = 'T'; board2[2 * 2][7 * 3].cell = 'E'; board2[2 * 2][8 * 3].cell = 'N';
            board2[4 * 2][7 * 3].cell = 'B'; board2[4 * 2][8 * 3].cell = 'Y'; board2[5 * 2][7 * 3].cell = 'E'; board2[6 * 2][7 * 3].cell = 'S'; board2[7 * 2][7 * 3].cell = 'T';
            board2[6 * 2][3 * 3].cell = 'G'; board2[6 * 2][4 * 3].cell = 'A'; board2[6 * 2][5 * 3].cell = 'M'; board2[6 * 2][6 * 3].cell = 'E';
            for (int i = 5; i < 28; i++) board[6][i].highLighted = true;
            for (int i = 0; i < board[0].Length; i++) for (int j = 0; j < board.Length; j++)
                {
                    Console.SetCursorPosition(15 + i, 2 + j);
                    if (board[j][i].highLighted)
                    {
                        Console.BackgroundColor = themes[settings.theme].HighlightedBackGround;
                        Console.Write(board[j][i].cell);
                        Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    }
                    else Console.Write(board[j][i].cell);
                }
            for (int i = 0; i < board2[0].Length; i++) for (int j = 0; j < board2.Length; j++)
                {
                    Console.SetCursorPosition(15 + i, 26 + j);
                    Console.Write(board2[j][i].cell);
                }
        }
        static bool exit(GameSetting settings)
        {
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            int index = 1, tempChar = 0;
            drawBox(42, 15, 25, 15, true, ' ');
            drawBox(42, 15, 25, 15, false, (char)177);
            Console.SetCursorPosition(49, 20);
            Console.Write("Are You Sure");
            while (true)
            {
                Console.SetCursorPosition(46, 25);
                Console.Write("                    ");
                if (index == 1)
                {
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.SetCursorPosition(48, 25);
                    Console.Write(" NO ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                    Console.SetCursorPosition(57, 25);
                    Console.Write(" YES ");
                }
                else if (index == 2)
                {
                    Console.SetCursorPosition(48, 25);
                    Console.Write(" NO ");
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.SetCursorPosition(57, 25);
                    Console.Write(" YES ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }

                while (true)
                {
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if(record.MouseEvent.dwButtonState==1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                            if (index == 1) return false;
                            else if (index == 2) return true;
                        }
                        if (record.MouseEvent.dwMousePosition.Y < 27 && record.MouseEvent.dwMousePosition.Y > 23 && record.MouseEvent.dwButtonState == 0)
                        {
                            if (record.MouseEvent.dwMousePosition.X < 52 && record.MouseEvent.dwMousePosition.X > 47 && index != 1)
                            {
                                index = 1; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.X < 62 && record.MouseEvent.dwMousePosition.X > 56 && index != 2)
                            {
                                index = 2; break;
                            }
                        }
                    }
                    else if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                    {
                        tempChar = record.KeyEvent.wVirtualKeyCode;
                        if (tempChar == (int)ConsoleKey.LeftArrow && index > 1)
                        {
                            index--; break;
                        }
                        else if (tempChar == (int)ConsoleKey.RightArrow && index < 2)
                        {
                            index++; break;
                        }
                        else if (tempChar == (int)ConsoleKey.Enter)
                        {
                            if (index == 1) return false;
                            else return true;
                        }
                    }
                }
            }
        }
        static void help(Encoding encoder,GameSetting settings,string[] helpTxt)
        {
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            drawBox(59, 3, 34, 43, true, ' ');
            drawBox(58, 42, 36, 5, false, (char)177);
            Console.SetCursorPosition(72, 44);
            Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
            Console.Write(" Back ");
            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
            int index = 0, sindex = 0;
            while (true)
            {
                for (int i = 0; i < 18; i++)
                {
                    Console.SetCursorPosition(63, 5 + i + i);
                    Console.Write("                             ");
                    Console.SetCursorPosition(63, 5 + i + i);
                    printASCII(helpTxt[i + index], encoder);
                }
                Console.SetCursorPosition(62, 44);
                Console.Write(" [Back]    [TOP]    [BOTTOM] ");
                if(sindex==0)
                {
                    Console.SetCursorPosition(62, 44);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [Back] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if(sindex==1)
                {
                    Console.SetCursorPosition(72, 44);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [TOP] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (sindex == 2)
                {
                    Console.SetCursorPosition(81, 44);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [BOTTOM] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                int key = 0;
                while (true)
                {
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                    {
                        key = record.KeyEvent.wVirtualKeyCode;
                        if (key == (int)ConsoleKey.Enter)
                        {
                            if(sindex==0) return;
                            else if(sindex==1) index = 0;
                            else if(sindex==2) index = 42; break;
                        }
                        else if(key==(int)ConsoleKey.LeftArrow && sindex>0)
                        {
                            sindex--; break;
                        }
                        else if (key == (int)ConsoleKey.RightArrow && sindex < 2)
                        {
                            sindex++; break;
                        }
                        else if (key == (int)ConsoleKey.UpArrow && index > 0)
                        {
                            index--; break;
                        }
                        else if (key == (int)ConsoleKey.DownArrow && index < helpTxt.Length - 18)
                        {
                            index++; break;
                        }
                    }
                    else if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                            key = (int)ConsoleKey.Enter;
                        }
                        if (key == (int)ConsoleKey.Enter)
                        {
                            if (sindex == 0) return;
                            else if (sindex == 1) index = 0;
                            else if (sindex == 2) index = helpTxt.Length-18; break;
                        }
                        if (record.MouseEvent.dwMousePosition.Y < 46 && record.MouseEvent.dwMousePosition.Y > 42 && record.MouseEvent.dwButtonState == 0)
                        {
                            if (record.MouseEvent.dwMousePosition.X > 61 && record.MouseEvent.dwMousePosition.X < 70 && sindex != 0)
                            {
                                sindex = 0; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 71 && record.MouseEvent.dwMousePosition.X < 79 && sindex != 1)
                            {
                                sindex = 1; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.X > 80 && record.MouseEvent.dwMousePosition.X < 90 && sindex != 2)
                            {
                                sindex = 2; break;
                            }
                        }
                        if (record.MouseEvent.dwButtonState == -7864320 && index < helpTxt.Length - 18)
                        {
                            index++; break;
                        }
                        if (record.MouseEvent.dwButtonState == 7864320 && index > 0)
                        {
                            index--; break;
                        }
                    }
                }
            }
        }
        static void saveGame(GameInfo gameInfo)
        {
            string[] gameInfoStr = new string[1670]; int index = 0;
            gameInfoStr[index] = Convert.ToString('\0'); index++;
            gameInfoStr[index] = Convert.ToString(gameInfo.formCounter); index++;
            for (int i = 0; i < gameInfo.gameboard.Length; i++) for (int j = 0; j < gameInfo.gameboard[i].Length; j++)
                {
                    gameInfoStr[index] = Convert.ToString(gameInfo.gameboard[i][j].cell);
                    index++;
                }
            gameInfoStr[index] = Convert.ToString(gameInfo.leftQuery); index++;
            for(int i=0;i<gameInfo.letters.Length;i++) for(int j=0;j<gameInfo.letters[i].Length;j++)
                {
                    gameInfoStr[index] = gameInfo.letters[i][j];
                    index++;
                }
            gameInfoStr[index] = Convert.ToString(gameInfo.numOfPass); index++;
            gameInfoStr[index] = Convert.ToString(gameInfo.player); index++;
            for(int i=0;i<gameInfo.players.Length;i++)
            {
                gameInfoStr[index] = new string(gameInfo.players[i].bag) + "," + gameInfo.players[i].name + "," + Convert.ToString(gameInfo.players[i].number) + "," + Convert.ToString(gameInfo.players[i].score); index++;
            }
            gameInfoStr[index] = Convert.ToString(gameInfo.round);
            File.WriteAllLines("svg", gameInfoStr);
        }
        static GameInfo loadSgame(GameInfo gameInfo,string[] gameInfoStr)
        {
            int index = 1;
            gameInfo.formCounter = Convert.ToInt32(gameInfoStr[index]); index++;
            for (int i = 0; i < gameInfo.gameboard.Length; i++) for (int j = 0; j < gameInfo.gameboard[i].Length; j++)
                {
                    gameInfo.gameboard[i][j].cell = gameInfoStr[index][0];
                    gameInfo.gameboard[i][j].highLighted = false;
                    index++;
                }
            gameInfo.leftQuery = Convert.ToInt32(gameInfoStr[index]); index++;
            for (int i = 0; i < gameInfo.letters.Length; i++) for (int j = 0; j < gameInfo.letters[i].Length; j++)
                {
                    gameInfo.letters[i][j] = gameInfoStr[index];
                    index++;
                }
            gameInfo.numOfPass = Convert.ToInt32(gameInfoStr[index]); index++;
            gameInfo.player = Convert.ToInt32(gameInfoStr[index]); index++;
            for (int i = 0; i < gameInfo.players.Length; i++)
            {
                string[] temp = gameInfoStr[index].Split(',');
                for (int j = 0; j < 7; j++) gameInfo.players[i].bag[j] = temp[0][j];
                gameInfo.players[i].name = temp[1];
                gameInfo.players[i].number = Convert.ToInt32(temp[2]);
                gameInfo.players[i].score = Convert.ToInt32(temp[3]); index++;
            }
            gameInfo.round = Convert.ToInt32(gameInfoStr[index]); return gameInfo;
        }
        static GameSetting loadSettings(string[] sets)
        {
            GameSetting settings = new GameSetting();
            settings.names = new string[2];
            settings.names[0] = sets[1];
            settings.names[1] = sets[2];
            settings.roundLimit = Convert.ToInt32(sets[3]);
            settings.seqPassLimit = Convert.ToInt32(sets[4]);
            settings.theme = Convert.ToInt32(sets[5]);
            return settings;
        }
        static void saveSettings(GameSetting settings)
        {
            string[] sets = new string[6];
            sets[0] = Convert.ToString('\0');
            sets[1] = settings.names[0];
            sets[2] = settings.names[1];
            sets[3] = Convert.ToString(settings.roundLimit);
            sets[4] = Convert.ToString(settings.seqPassLimit);
            sets[5] = Convert.ToString(settings.theme);
            File.WriteAllLines("sets", sets); return;
        }
        static void setting(GameSetting settings, Encoding encoder)
        {
            int tempTheme = settings.theme;
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            drawBox(59, 3, 34, 43, true, ' ');
            drawBox(58, 42, 36, 5, false, (char)177);
            int index = 0;
            while (true)
            {
                Console.SetCursorPosition(66, 44);
                Console.Write(" [BACK]      [SAVE] ");
                Console.SetCursorPosition(64, 7);
                Console.Write("Change players' names");
                Console.SetCursorPosition(77, 9);
                Console.Write("               ");
                Console.SetCursorPosition(66, 9);
                Console.Write("1. Player: ");
                printASCII(" " + settings.names[0] + " ", encoder);
                Console.SetCursorPosition(77, 12);
                Console.Write("               ");
                Console.SetCursorPosition(66, 12);
                Console.Write("2. Player: ");
                printASCII(" " + settings.names[1] + " ", encoder);
                Console.SetCursorPosition(64, 16);
                Console.Write("Set round limit (MIN 10)");
                Console.SetCursorPosition(66, 18);
                Console.Write(" " + settings.roundLimit + " ");
                Console.SetCursorPosition(64, 22);
                Console.Write("Set sequential pass limit");
                Console.SetCursorPosition(64, 23);
                Console.Write("(Range 4-9)");
                Console.SetCursorPosition(66, 25);
                Console.Write(" " + settings.seqPassLimit + " ");
                Console.SetCursorPosition(64, 29);
                Console.Write("Select theme");
                Console.SetCursorPosition(66, 31);
                Console.Write("         ");
                Console.SetCursorPosition(66, 31);
                if (tempTheme == 0)
                {
                    Console.Write(" Default ");
                }
                else if (tempTheme == 1)
                {
                    Console.Write(" Dark ");
                }
                else if (tempTheme == 2)
                {
                    Console.Write(" Light ");
                }
                if (index == 0)
                {
                    Console.SetCursorPosition(77, 9);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    printASCII(" " + settings.names[0] + " ", encoder);
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (index == 1)
                {
                    Console.SetCursorPosition(77, 12);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    printASCII(" " + settings.names[1] + " ", encoder);
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (index == 2)
                {
                    Console.SetCursorPosition(66, 18);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" " + settings.roundLimit + " ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (index == 3)
                {
                    Console.SetCursorPosition(66, 25);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" " + settings.seqPassLimit + " ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (index == 4)
                {
                    Console.SetCursorPosition(66, 31);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    if (tempTheme == 0)
                    {
                        Console.Write(" Default ");
                    }
                    else if (tempTheme == 1)
                    {
                        Console.Write(" Dark ");
                    }
                    else if (tempTheme == 2)
                    {
                        Console.Write(" Light ");
                    }
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (index == 5)
                {
                    Console.SetCursorPosition(66, 44);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [BACK] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                else if (index == 6)
                {
                    Console.SetCursorPosition(78, 44);
                    Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                    Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                    Console.Write(" [SAVE] ");
                    Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                }
                int key = 0;
                while (true)
                {
                    key = 0;
                    record = NativeMethods.RecordEvent(handle, record);
                    if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                    {
                        key = record.KeyEvent.wVirtualKeyCode;
                        if (key == (int)ConsoleKey.Enter) break;
                        else if (key == (int)ConsoleKey.LeftArrow && index == 6)
                        {
                            index = 5; break;
                        }
                        else if (key == (int)ConsoleKey.RightArrow && index == 5)
                        {
                            index = 6; break;
                        }
                        else if (key == (int)ConsoleKey.UpArrow)
                        {
                            if (index > 4) index = 4;
                            else if (index < 5&& index >0) index--;
                            break;
                        }
                        else if (key == (int)ConsoleKey.DownArrow)
                        {
                            if (index == 4) index = 5;
                            else if (index < 4) index++;
                            break;
                        }
                        else if (key == (int)ConsoleKey.Tab)
                        {
                            index = 5;
                            break;
                        }
                    }
                    else if (record.EventType == NativeMethods.MOUSE_EVENT)
                    {
                        if (record.MouseEvent.dwButtonState == 1)
                        {
                            while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                            key = (int)ConsoleKey.Enter;
                            break;
                        }
                        if (record.MouseEvent.dwMousePosition.X > 65 && record.MouseEvent.dwMousePosition.X < 87)
                        {
                            if (record.MouseEvent.dwMousePosition.Y < 46 && record.MouseEvent.dwMousePosition.Y > 42 && record.MouseEvent.dwButtonState == 0)
                            {
                                if (record.MouseEvent.dwMousePosition.X > 65 && record.MouseEvent.dwMousePosition.X < 74 && index != 5)
                                {
                                    index = 5; break;
                                }
                                else if (record.MouseEvent.dwMousePosition.X > 77 && record.MouseEvent.dwMousePosition.X < 86 && index != 6)
                                {
                                    index = 6; break;
                                }
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 11 && record.MouseEvent.dwMousePosition.Y > 7 && index != 0)
                            {
                                index = 0; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 14 && record.MouseEvent.dwMousePosition.Y > 10 && index != 1)
                            {
                                index = 1; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 20 && record.MouseEvent.dwMousePosition.Y > 16 && index != 2)
                            {
                                index = 2; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 27 && record.MouseEvent.dwMousePosition.Y > 23 && index != 3)
                            {
                                index = 3; break;
                            }
                            else if (record.MouseEvent.dwMousePosition.Y < 33 && record.MouseEvent.dwMousePosition.Y > 29 && index != 4)
                            {
                                index = 4; break;
                            }
                        }
                    }
                }
                if (key == (int)ConsoleKey.Enter)
                {
                    Console.SetCursorPosition(68, 40);
                    Console.Write("              ");
                    if (index == 0)
                    {
                        drawBox(64, 15, 25, 15, true, ' ');
                        drawBox(64, 15, 25, 15, false, (char)177);
                        Console.SetCursorPosition(69, 20);
                        Console.Write("1. Player's name");
                        Console.SetCursorPosition(69, 22);
                        Console.OutputEncoding = encoder;
                        int maxLength = 13;
                        char[] Chr = new char[maxLength + 1];
                        while (true)
                        {
                            char tempKey;
                            ConsoleKeyInfo cki = Console.ReadKey(true);
                            tempKey = cki.KeyChar;
                            if (maxLength > 0 && ((tempKey <= 'Z' && tempKey >= 'A') || (tempKey <= '9' && tempKey >= '0') || (tempKey <= 'z' && tempKey >= 'a') || tempKey == ' ' || tempKey == 'ü' || tempKey == 'Ü' || tempKey == 'ğ' || tempKey == 'Ğ' || tempKey == 'İ' || tempKey == 'ı' || tempKey == 'ş' || tempKey == 'Ş' || tempKey == 'ö' || tempKey == 'Ö' || tempKey == 'ç' || tempKey == 'Ç'))
                            {
                                Console.Write((char)tempKey);
                                Chr[13 - maxLength] = (char)tempKey;
                                maxLength--;
                            }
                            else if (ConsoleKey.Backspace == cki.Key && maxLength < 13)
                            {
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                Console.Write(' ');
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                maxLength++;
                                Chr[13 - maxLength] = '\0';
                            }
                            else if (ConsoleKey.Enter == cki.Key)
                            {
                                string name = new string(Chr, 0, 13 - maxLength);
                                if (name != "" && name[0] != ' '&&name!=settings.names[1]) settings.names[0] = name;
                                Console.OutputEncoding = System.Text.Encoding.Default;
                                drawBox(59, 3, 34, 43, true, ' ');
                                drawBox(58, 42, 36, 5, false, (char)177);
                                break;
                            }
                        }
                    }
                    else if (index == 1)
                    {
                        drawBox(64, 15, 25, 15, true, ' ');
                        drawBox(64, 15, 25, 15, false, (char)177);
                        Console.SetCursorPosition(69, 20);
                        Console.Write("2. Player's name");
                        Console.SetCursorPosition(69, 22);
                        Console.OutputEncoding = encoder;
                        int maxLength = 13;
                        char[] Chr = new char[maxLength + 1];
                        while (true)
                        {
                            char tempKey;
                            ConsoleKeyInfo cki = Console.ReadKey(true);
                            tempKey = cki.KeyChar;
                            if (maxLength > 0 && ((tempKey <= 'Z' && tempKey >= 'A') || (tempKey <= '9' && tempKey >= '0') || (tempKey <= 'z' && tempKey >= 'a') || tempKey == ' ' || tempKey == 'ü' || tempKey == 'Ü' || tempKey == 'ğ' || tempKey == 'Ğ' || tempKey == 'İ' || tempKey == 'ı' || tempKey == 'ş' || tempKey == 'Ş' || tempKey == 'ö' || tempKey == 'Ö' || tempKey == 'ç' || tempKey == 'Ç'))
                            {
                                Console.Write((char)tempKey);
                                Chr[13 - maxLength] = (char)tempKey;
                                maxLength--;
                            }
                            else if (ConsoleKey.Backspace == cki.Key && maxLength < 13)
                            {
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                Console.Write(' ');
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                maxLength++;
                                Chr[13 - maxLength] = '\0';
                            }
                            else if (ConsoleKey.Enter == cki.Key)
                            {
                                string name = new string(Chr, 0, 13 - maxLength);
                                if (name != "" && name[0] != ' '&&name!=settings.names[0]) settings.names[1] = name;
                                Console.OutputEncoding = System.Text.Encoding.Default;
                                drawBox(59, 3, 34, 43, true, ' ');
                                drawBox(58, 42, 36, 5, false, (char)177);
                                break;
                            }
                        }
                    }
                    else if (index == 2)
                    {
                        drawBox(64, 15, 25, 15, true, ' ');
                        drawBox(64, 15, 25, 15, false, (char)177);
                        Console.SetCursorPosition(69, 20);
                        Console.Write("Enter limit");
                        Console.SetCursorPosition(67, 21);
                        Console.Write("(0) Mean unlimited");
                        Console.SetCursorPosition(69, 23);
                        int maxLength = 3;
                        char[] Chr = new char[maxLength + 1];
                        while (true)
                        {
                            char tempKey;
                            ConsoleKeyInfo cki = Console.ReadKey(true);
                            tempKey = cki.KeyChar;
                            if (maxLength > 0 && (tempKey <= '9' && tempKey >= '0'))
                            {
                                Console.Write((char)tempKey);
                                Chr[3 - maxLength] = (char)tempKey;
                                maxLength--;
                            }
                            else if (ConsoleKey.Backspace == cki.Key && maxLength < 3)
                            {
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                Console.Write(' ');
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                maxLength++;
                                Chr[3 - maxLength] = '\0';
                            }
                            else if (ConsoleKey.Enter == cki.Key)
                            {
                                string str = new string(Chr, 0, 3 - maxLength);
                                if (str != "")
                                {
                                    int number = Convert.ToInt32(str);
                                    if (number == 0 || number > 9) settings.roundLimit = number;
                                }
                                drawBox(59, 3, 34, 43, true, ' ');
                                drawBox(58, 42, 36, 5, false, (char)177);
                                break;
                            }
                        }
                    }
                    else if (index == 3)
                    {
                        drawBox(64, 15, 25, 15, true, ' ');
                        drawBox(64, 15, 25, 15, false, (char)177);
                        Console.SetCursorPosition(69, 20);
                        Console.Write("Enter limit");
                        Console.SetCursorPosition(69, 22);
                        int maxLength = 1;
                        char[] Chr = new char[2];
                        while (true)
                        {
                            char tempKey;
                            ConsoleKeyInfo cki = Console.ReadKey(true);
                            tempKey = cki.KeyChar;
                            if (maxLength > 0 && (tempKey <= '9' && tempKey >= '0'))
                            {
                                Console.Write((char)tempKey);
                                Chr[0] = (char)tempKey;
                                maxLength--;
                            }
                            else if (ConsoleKey.Backspace == cki.Key && maxLength < 1)
                            {
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                Console.Write(' ');
                                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                                maxLength++;
                                Chr[0] = '\0';
                            }
                            else if (ConsoleKey.Enter == cki.Key)
                            {
                                string str = new string(Chr, 0, 1 - maxLength);
                                if (str != "")
                                {
                                    int number = Convert.ToInt32(str);
                                    if (number >= 4 && number <= 9) settings.seqPassLimit = number;
                                }
                                drawBox(59, 3, 34, 43, true, ' ');
                                drawBox(58, 42, 36, 5, false, (char)177);
                                break;
                            }
                        }
                    }
                    else if (index == 4)
                    {
                        int tempIndex = 0, tempKey = 0;
                        drawBox(64, 15, 25, 15, true, ' ');
                        drawBox(64, 15, 25, 15, false, (char)177);
                        while (true)
                        {
                            if (tempIndex == 0)
                            {
                                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                            }
                            else
                            {
                                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                            }
                            Console.SetCursorPosition(69, 19);
                            Console.Write(" Default ");
                            if (tempIndex == 1)
                            {
                                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                            }
                            else
                            {
                                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                            }
                            Console.SetCursorPosition(69, 22);
                            Console.Write(" Dark ");
                            if (tempIndex == 2)
                            {
                                Console.BackgroundColor = themes[settings.theme].IndexedBackGround;
                                Console.ForegroundColor = themes[settings.theme].IndexedForeground;
                            }
                            else
                            {
                                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                            }
                            Console.SetCursorPosition(69, 25);
                            Console.Write(" Light ");
                            Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                            while (true)
                            {
                                tempKey = 0;
                                record = NativeMethods.RecordEvent(handle, record);
                                if (record.EventType == NativeMethods.KEY_EVENT && record.KeyEvent.bKeyDown)
                                {
                                    tempKey = (int)record.KeyEvent.wVirtualKeyCode;
                                    if (tempKey == (int)ConsoleKey.UpArrow && tempIndex > 0)
                                    {
                                        tempIndex--;
                                    }
                                    else if (tempKey == (int)ConsoleKey.DownArrow && tempIndex < 2)
                                    {
                                        tempIndex++;
                                    }
                                    break;
                                }
                                else if (record.EventType == NativeMethods.MOUSE_EVENT)
                                {
                                    if (record.MouseEvent.dwButtonState == 1)
                                    {
                                        while (record.MouseEvent.dwButtonState != 0) record = NativeMethods.RecordEvent(handle, record);
                                        tempKey = (int)ConsoleKey.Enter;
                                        break;
                                    }
                                    if (record.MouseEvent.dwButtonState == 0)
                                    {
                                        if (record.MouseEvent.dwMousePosition.X > 68 && record.MouseEvent.dwMousePosition.X < 80)
                                        {
                                            if (record.MouseEvent.dwMousePosition.Y < 21 && record.MouseEvent.dwMousePosition.Y > 17 && tempIndex != 0)
                                            {
                                                tempIndex = 0; break;
                                            }
                                            else if (record.MouseEvent.dwMousePosition.Y < 24 && record.MouseEvent.dwMousePosition.Y > 20 && tempIndex != 1)
                                            {
                                                tempIndex = 1; break;
                                            }
                                            else if (record.MouseEvent.dwMousePosition.Y < 27 && record.MouseEvent.dwMousePosition.Y > 23 && tempIndex != 2)
                                            {
                                                tempIndex = 2; break;
                                            }
                                        }
                                    }
                                }
                            }
                            if(tempKey==(int)ConsoleKey.Enter)
                            {
                                Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                                Console.ForegroundColor = themes[settings.theme].DefaultForeGround;
                                drawBox(59, 3, 34, 43, true, ' ');
                                drawBox(58, 42, 36, 5, false, (char)177);
                                tempTheme = tempIndex;
                                break;
                            }
                        }
                    }
                    else if (index == 5) return;
                    else if (index == 6)
                    {
                        if(settings.theme!=tempTheme)
                        {
                            settings.theme = tempTheme;
                            initializeConsole(50, 110, tempTheme);
                            Console.Clear();
                            drawMenuScreen(settings);
                            drawBox(59, 3, 34, 43, true, ' ');
                            drawBox(58, 2, 36, 45, false, (char)177);
                            drawBox(58, 42, 36, 5, false, (char)177);
                        }
                        saveSettings(settings);
                        Console.SetCursorPosition(68, 40);
                        Console.Write("Settings Saved");
                    }
                }
            }
        }
        static void createThemes()
        {
            themes[0].DefaultBackGround = ConsoleColor.Yellow;
            themes[0].DefaultForeGround = ConsoleColor.DarkMagenta;
            themes[0].BagForeGroung = ConsoleColor.DarkRed;
            themes[0].BoardForeGround = ConsoleColor.DarkYellow;
            themes[0].HighlightedBackGround = ConsoleColor.Cyan;
            themes[0].IndexedBackGround = ConsoleColor.DarkMagenta;
            themes[0].IndexedForeground = ConsoleColor.Cyan;
            themes[0].PopUpBackGround = ConsoleColor.Cyan;
            themes[0].SelectedBackGround = ConsoleColor.Blue;
            themes[0].SelectedForeground = ConsoleColor.White;

            themes[1].DefaultBackGround = ConsoleColor.Black;
            themes[1].DefaultForeGround = ConsoleColor.Gray;
            themes[1].BagForeGroung = ConsoleColor.Gray;
            themes[1].BoardForeGround = ConsoleColor.Gray;
            themes[1].HighlightedBackGround = ConsoleColor.DarkCyan;
            themes[1].IndexedBackGround = ConsoleColor.Blue;
            themes[1].IndexedForeground = ConsoleColor.Gray;
            themes[1].PopUpBackGround = ConsoleColor.Black;
            themes[1].SelectedBackGround = ConsoleColor.White;
            themes[1].SelectedForeground = ConsoleColor.Black;

            themes[2].DefaultBackGround = ConsoleColor.White;
            themes[2].DefaultForeGround = ConsoleColor.Black;
            themes[2].BagForeGroung = ConsoleColor.Black;
            themes[2].BoardForeGround = ConsoleColor.Black;
            themes[2].HighlightedBackGround = ConsoleColor.Cyan;
            themes[2].IndexedBackGround = ConsoleColor.Gray;
            themes[2].IndexedForeground = ConsoleColor.Black;
            themes[2].PopUpBackGround = ConsoleColor.White;
            themes[2].SelectedBackGround = ConsoleColor.Black;
            themes[2].SelectedForeground = ConsoleColor.White;
        }
        static void intro(GameSetting settings)
        {
            GameboardCell[][] board = createGameboard(21, 33);
            board[6 * 2][8 * 3].cell = 'M'; board[6 * 2][7 * 3].cell = 'A'; board[6 * 2][6 * 3].cell = 'G'; board[5 * 2][4 * 3].cell = 'W'; board[4 * 2][4 * 3].cell = 'O';
            board[7 * 2][9 * 3].cell = 'R'; board[6 * 2][9 * 3].cell = 'E'; board[5 * 2][9 * 3].cell = 'T'; board[4 * 2][9 * 3].cell = 'T'; board[2 * 2][9 * 3].cell = 'L';
            board[3 * 2][9 * 3].cell = 'E'; board[3 * 2][8 * 3].cell = 'L'; board[3 * 2][7 * 3].cell = 'B'; board[3 * 2][6 * 3].cell = 'B'; board[3 * 2][5 * 3].cell = 'I';
            board[3 * 2][4 * 3].cell = 'R'; board[3 * 2][3 * 3].cell = 'C'; board[3 * 2][2 * 3].cell = 'S';
            for (int i = 5; i < 28; i++) board[6][i].highLighted = true;
            for (int i = 0; i < board[0].Length; i++) for (int j = 0; j < board.Length; j++)
                {
                    System.Threading.Thread.Sleep(1);
                    Console.SetCursorPosition(38 + i, 14 + j);
                    if (board[j][i].highLighted)
                    {
                        Console.BackgroundColor = themes[settings.theme].HighlightedBackGround;
                        Console.Write(board[j][i].cell);
                        Console.BackgroundColor = themes[settings.theme].DefaultBackGround;
                    }
                    else Console.Write(board[j][i].cell);
                }
            NativeMethods.ConsoleHandle handle = NativeMethods.IntegrateReader();
            NativeMethods.INPUT_RECORD record = new NativeMethods.INPUT_RECORD();
            while(true)
            {
                record = NativeMethods.RecordEvent(handle, record);
                if(record.EventType==NativeMethods.MOUSE_EVENT&&record.MouseEvent.dwButtonState==1)
                {
                    while(true)
                    {
                        record = NativeMethods.RecordEvent(handle, record);
                        if (record.MouseEvent.dwButtonState == 0) break;
                    }
                    break;
                }
                if(record.EventType==NativeMethods.KEY_EVENT&&record.KeyEvent.bKeyDown)
                {
                    record = NativeMethods.RecordEvent(handle, record);
                    if (!record.KeyEvent.bKeyDown) break;
                }
            }
        }
    }
    class NativeMethods
    {
        public const Int32 STD_INPUT_HANDLE = -10;
        public const Int32 ENABLE_MOUSE_INPUT = 0x0010;
        public const Int32 ENABLE_QUICK_EDIT_MODE = 0x0040;
        public const Int32 ENABLE_EXTENDED_FLAGS = 0x0080;
        public const Int32 KEY_EVENT = 1;
        public const Int32 MOUSE_EVENT = 2;
        [DebuggerDisplay("EventType: {EventType}")]
        [StructLayout(LayoutKind.Explicit)]
        public struct INPUT_RECORD
        {
            [FieldOffset(0)]
            public Int16 EventType;
            [FieldOffset(4)]
            public KEY_EVENT_RECORD KeyEvent;
            [FieldOffset(4)]
            public MOUSE_EVENT_RECORD MouseEvent;
        }
        [DebuggerDisplay("{dwMousePosition.X}, {dwMousePosition.Y}")]
        public struct MOUSE_EVENT_RECORD
        {
            public COORD dwMousePosition;
            public Int32 dwButtonState;
            public Int32 dwControlKeyState;
            public Int32 dwEventFlags;
        }
        [DebuggerDisplay("{X}, {Y}")]
        public struct COORD
        {
            public UInt16 X; public UInt16 Y;
        }
        [DebuggerDisplay("KeyCode: {wVirtualKeyCode}")]
        [StructLayout(LayoutKind.Explicit)]
        public struct KEY_EVENT_RECORD
        {
            [FieldOffset(0)]
            [MarshalAsAttribute(UnmanagedType.Bool)]
            public Boolean bKeyDown;
            [FieldOffset(4)]
            public UInt16 wRepeatCount;
            [FieldOffset(6)]
            public UInt16 wVirtualKeyCode;
            [FieldOffset(8)]
            public UInt16 wVirtualScanCode;
            [FieldOffset(10)]
            public Char UnicodeChar;
            [FieldOffset(10)]
            public Byte AsciiChar;
            [FieldOffset(12)]
            public Int32 dwControlKeyState;
        };
        public class ConsoleHandle : SafeHandleMinusOneIsInvalid
        {
            public ConsoleHandle() : base(false) { }
            protected override bool ReleaseHandle()
            {
                return true; //releasing console handle is not our business
            }
        }
        [DllImportAttribute("kernel32.dll", SetLastError = true)]
        [return: MarshalAsAttribute(UnmanagedType.Bool)]
        public static extern Boolean GetConsoleMode(ConsoleHandle hConsoleHandle, ref Int32 lpMode);
        [DllImportAttribute("kernel32.dll", SetLastError = true)]
        public static extern ConsoleHandle GetStdHandle(Int32 nStdHandle);
        [DllImportAttribute("kernel32.dll", SetLastError = true)]
        [return: MarshalAsAttribute(UnmanagedType.Bool)]
        public static extern Boolean ReadConsoleInput(ConsoleHandle hConsoleInput, ref INPUT_RECORD lpBuffer,
        UInt32 nLength, ref UInt32 lpNumberOfEventsRead);
        [DllImportAttribute("kernel32.dll", SetLastError = true)]
        [return: MarshalAsAttribute(UnmanagedType.Bool)]
        public static extern Boolean SetConsoleMode(ConsoleHandle hConsoleHandle, Int32 dwMode);
        public static ConsoleHandle IntegrateReader()
        {
            var handle = NativeMethods.GetStdHandle(NativeMethods.STD_INPUT_HANDLE); int mode = 0;
            if (!(NativeMethods.GetConsoleMode(handle, ref mode))) { throw new Win32Exception(); }
            mode |= NativeMethods.ENABLE_MOUSE_INPUT;
            mode &= ~NativeMethods.ENABLE_QUICK_EDIT_MODE;
            mode |= NativeMethods.ENABLE_EXTENDED_FLAGS;
            if (!(NativeMethods.SetConsoleMode(handle, mode))) { throw new Win32Exception(); } return handle;
        }
        public static NativeMethods.INPUT_RECORD RecordEvent(NativeMethods.ConsoleHandle handle, NativeMethods.INPUT_RECORD record)
        {
            uint recordLen = 0;
            NativeMethods.ReadConsoleInput(handle, ref record, 1, ref recordLen);
            return record;
        }
    }
}
